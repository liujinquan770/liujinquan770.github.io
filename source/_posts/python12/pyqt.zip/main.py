# -*- coding: utf-8 -*-
import sys
from PyQt5.QtWidgets import QApplication
import Handler_dlg_main

if __name__ == "__main__":
    app = QApplication(sys.argv)
    with open('dark_orange.qss') as file:
        str = file.readlines()
        str =''.join(str).strip('\n')
    app.setStyleSheet(str)
    login = Handler_dlg_main.Handler_DlgMain()
    login.show()
    sys.exit(app.exec_())