# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'e:\liujinquan\python\pyqt\dlg_main.ui'
#
# Created by: PyQt5 UI code generator 5.10.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_DlgMain(object):
    def setupUi(self, DlgMain):
        DlgMain.setObjectName("DlgMain")
        DlgMain.resize(800, 600)
        self.btn1 = QtWidgets.QPushButton(DlgMain)
        self.btn1.setGeometry(QtCore.QRect(90, 70, 75, 23))
        self.btn1.setObjectName("btn1")
        self.resultLabel = QtWidgets.QLabel(DlgMain)
        self.resultLabel.setGeometry(QtCore.QRect(90, 110, 261, 41))
        self.resultLabel.setObjectName("resultLabel")

        self.retranslateUi(DlgMain)
        QtCore.QMetaObject.connectSlotsByName(DlgMain)

    def retranslateUi(self, DlgMain):
        _translate = QtCore.QCoreApplication.translate
        DlgMain.setWindowTitle(_translate("DlgMain", "窗口1"))
        self.btn1.setText(_translate("DlgMain", "button1"))
        self.resultLabel.setText(_translate("DlgMain", "TextLabel"))

