# -*- coding: utf-8 -*-
import sys
from PyQt5.QtWidgets import QDialog, QMessageBox
from Ui_dlg_main import Ui_DlgMain


class Handler_DlgMain(QDialog):
    def __init__(self, parent=None):
        super(Handler_DlgMain, self).__init__(parent)
        self.ui = Ui_DlgMain()
        self.ui.setupUi(self)
        self.ui.btn1.clicked.connect(self.slotLogin)

    def slotLogin(self):
        button = QMessageBox.question(self, "Question", "检测到程序有更新，是否安装最新版本？",
                                      QMessageBox.Ok | QMessageBox.Cancel, QMessageBox.Ok)

        if button == QMessageBox.Ok:
            self.ui.resultLabel.setText(
                "<h2>Question:<font color=red>  OK</font></h2>")
        elif button == QMessageBox.Cancel:
            self.ui.resultLabel.setText(
                "<h2>Question:<font color=red>  Cancel</font></h2>")
        else:
            return
