﻿using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;
using System;

namespace CustomProtocol
{
    public class CustomProtocolSession : AppSession<CustomProtocolSession, BinaryRequestInfo>
    {
        protected override void HandleException(Exception e)
        {
            base.HandleException(e);
        }

        protected override void HandleUnknownRequest(BinaryRequestInfo requestInfo)
        {
            base.HandleUnknownRequest(requestInfo);
        }

        protected override void OnInit()
        {
            base.OnInit();
        }

        protected override void OnSessionClosed(SuperSocket.SocketBase.CloseReason reason)
        {
            string log = string.Format("session {0} closed, reason is {1}", SessionID, reason);
            Console.WriteLine(log);
            base.OnSessionClosed(reason);
        }

        protected override void OnSessionStarted()
        {
            string log = string.Format("session {0} started", SessionID);
            Console.WriteLine(log);

            base.OnSessionStarted();
        }
    }
}