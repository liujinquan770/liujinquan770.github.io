﻿using SuperSocket.Common;
using SuperSocket.Facility.Protocol;
using SuperSocket.SocketBase.Protocol;
using System;
using System.Linq;
using System.Text;

namespace CustomProtocol
{
    class MyReceiveFilter : FixedHeaderReceiveFilter<BinaryRequestInfo>
    {
        const int header_len = 4;

        private int total_len = 0;
        private byte[] total_data;
        public MyReceiveFilter() : base(header_len)
        {
        }

        public override BinaryRequestInfo Filter(byte[] readBuffer, int offset, int length, bool toBeCopied, out int rest)
        {
            var data = readBuffer.Skip(offset).Take(length).ToArray();

            return base.Filter(readBuffer, offset, length, toBeCopied, out rest);
        }

        protected override int GetBodyLengthFromHeader(byte[] header, int offset, int length)
        {
            //byte[] btLen = header.Skip(4).Take(2).ToArray();
            //int len = btLen[0] * 256 + btLen[1];
            ////len = BitConverter.ToInt16(btLen, 0);
            //return len;

            return (int)header[offset + header_len-2] * 256 + (int)header[offset + header_len-1];

            //return 100;
        }

        protected override BinaryRequestInfo ProcessMatchedRequest(byte[] buffer, int offset, int length, bool toBeCopied)
        {
            total_len = length;
            total_data = buffer.Skip(offset).Take(total_len).ToArray();
            return base.ProcessMatchedRequest(buffer, offset, length, toBeCopied);
        }

        protected override BinaryRequestInfo ResolveRequestInfo(ArraySegment<byte> header, byte[] bodyBuffer, int offset, int length)
        {
            //return new BinaryRequestInfo(Encoding.UTF8.GetString(header.Array, header.Offset, 4), bodyBuffer.CloneRange(offset, length));

            var head = header.ToArray();
            var data = bodyBuffer.Skip(offset).Take(length);
            //return new BinaryRequestInfo(Encoding.UTF8.GetString(header.Array, header.Offset, 1), bodyBuffer.CloneRange(offset, length));
            var all = head.Concat(data).ToArray();

            Console.WriteLine(string.Join(",", total_data));
            return new BinaryRequestInfo("hello", total_data);
        }
    }
}