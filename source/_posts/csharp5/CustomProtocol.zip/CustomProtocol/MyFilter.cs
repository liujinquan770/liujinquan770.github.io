﻿using SuperSocket.SocketBase.Protocol;
using System;
using System.Linq;

namespace CustomProtocol
{
    public class MyFilter : IReceiveFilter<BinaryRequestInfo>
    {
        public int LeftBufferSize { get; }

        public IReceiveFilter<BinaryRequestInfo> NextReceiveFilter { get; }

        public FilterState State { get; }

        public BinaryRequestInfo Filter(byte[] readBuffer, int offset, int length, bool toBeCopied, out int rest)
        {
            rest = 0;
            var data = readBuffer.Skip(offset).Take(length).ToArray();

            string log = BitConverter.ToString(data);
            Console.WriteLine(log);
            return new BinaryRequestInfo("hello", data);
        }

        public void Reset()
        {
        }
    }
}